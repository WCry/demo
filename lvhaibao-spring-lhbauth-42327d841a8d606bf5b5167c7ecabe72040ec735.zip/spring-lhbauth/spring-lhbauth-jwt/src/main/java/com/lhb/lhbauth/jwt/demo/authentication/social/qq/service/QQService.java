package com.lhb.lhbauth.jwt.demo.authentication.social.qq.service;

import com.lhb.lhbauth.jwt.demo.authentication.social.qq.model.QQUserInfo;

/**
 * @author lvhaibao
 * @description
 * @date 2019/1/3 0003 9:57
 */
public interface QQService {

    QQUserInfo getUserInfo();
}
